#include<iostream>
#include<vector>
using namespace std;
class Graph
{
private:
    int numberOfVertices;
    vector<int>* adjacent;
public:
    Graph(int V)
    {
        numberOfVertices = V;
        adjacent = new vector<int>[V];
    }
    void addEdge(int scr , int dest)
    {
        adjacent[scr].push_back(dest);
    }
    bool CyclicRec(vector<int> adj[] , int startingPoint , vector<bool>& visited, vector<bool>& recursionStacked)
    {
        visited[startingPoint] = true;
        recursionStacked[startingPoint] = true;
        for(int u : adj[startingPoint])
        {
            if(!visited[u] && CyclicRec(adj , u , visited, recursionStacked))
                return true;
            else if(recursionStacked[u] == true)
                return true;
        }
        recursionStacked[startingPoint] = false;
        return false;
    }
    bool Cyclic()
    {
        vector<bool> visited;
        visited.resize(numberOfVertices , false);
        vector<bool>recursionStacked;
        recursionStacked.resize(numberOfVertices, false);
        for(int i = 0; i < numberOfVertices; i++)
        {
            if(!visited[i] && CyclicRec(adjacent , i , visited , recursionStacked))
                return true;
        }
        return false;
    }
};



int main()
{
    Graph g(4);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 2);
    g.addEdge(2, 0);
    g.addEdge(2, 3);
    g.addEdge(3, 3);
    if(g.Cyclic())
        cout<<"Cyclic"<<endl;
    else
        cout<<"NoCyclic"<<endl;
    return 0;
}