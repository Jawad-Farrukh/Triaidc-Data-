#include<iostream>
#include<vector>
#include<queue>
using namespace std;
class Graph
{
private:
	int numberOfVertices;
	vector<int>* graph;
public:
	Graph(int V)
	{
		numberOfVertices = V;
		graph = new vector<int>[V];
	}
	void addEdge(int scr, int dest)
	{
		graph[scr].push_back(dest);
		graph[dest].push_back(scr);
	}
	void BFS(int scr)
	{
		vector<bool> visited;
		visited.resize(numberOfVertices);
		for (int i = 0; i < numberOfVertices; i++)
		{
			visited[i] = false;
		}
		queue<int> Q;
		visited[scr] = true;
		Q.push(scr);
		while (!Q.empty())
		{
			scr = Q.front();
			cout << scr << " ";
			Q.pop();
			for (int i = 0; i < graph[scr].size(); i++)
			{
				if (!visited[i])
				{
					visited[i] = true;
					Q.push(i);
				}
			}
		}
	}
};
int main()
{
	Graph g(4);
	g.addEdge(0, 1);
	g.addEdge(0, 2);
	g.addEdge(1, 2);
	g.addEdge(2, 0);
	g.addEdge(2, 3);
	g.addEdge(3, 3);
	g.BFS(2);
	return  0;
}