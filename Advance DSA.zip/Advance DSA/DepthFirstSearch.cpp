#include<iostream>
#include<vector>
using namespace std;
class Graph
{
    private:
        int numberOfVertices;
        vector<int>* adjacentVertices;
    public:
        Graph(int V)
        {
            numberOfVertices = V;
            adjacentVertices = new vector<int>[V];
        }
        void addEdge(int scr , int dest)
        {
            adjacentVertices[scr].push_back(dest);
            adjacentVertices[dest].push_back(scr);
        }
        void DFSRec(int scr , vector<int> adjacentVertices[] , vector<bool> &visited)
        {
            visited[scr] = true;
            cout<<scr<<" ";
            for(int u : adjacentVertices[scr])
            {
                if(visited[u] == false)
                    DFSRec(u , adjacentVertices , visited);
            }
        }
        void DFS(int startingPoint)
        {
            vector<bool> visited;
            visited.resize(numberOfVertices , false);
            DFSRec(startingPoint , adjacentVertices , visited);
        }
};
int main()
{
    Graph g(4);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 2);
    g.addEdge(2, 0);
    g.addEdge(2, 3);
    g.addEdge(3, 3);
    g.DFS(2);
    return 0;
}