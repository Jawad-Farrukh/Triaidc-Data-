#include<iostream>
#include<stack>
#include<deque>
using namespace std;
class SpecialStack
{
    stack<int>S1;
    deque<int>DQ1;
public:
    void push(int value)
    {
        DQ1.push_back(value);
        if(DQ1.size() > S1.size() + 1)
        {
            int temp = DQ1.front();
            DQ1.pop_front();
            S1.push(temp);
        }
    }
    int pop()
    {
        if(DQ1.empty())
        {
            cout<<"Stack Is Empty"<<endl;
            return -1;
        }
        int temp = DQ1.back();
        DQ1.pop_back();
        if(DQ1.size() < S1.size())
        {
            int temp2 = S1.top();
            S1.pop();
            DQ1.push_front(temp2);
        }
        return temp;
    }
    void middle()
    {
        if(DQ1.empty())
        {
            cout<<"Stack Is Empty"<<endl;
            return;
        }
        cout<<DQ1.front()<<endl;
    }
    void deleteMiddle()
    {
        DQ1.pop_front();
        if(DQ1.empty())
        {
            cout<<"Stack Is Empty"<<endl;
            return;
        }
        else if(DQ1.size() < S1.size())
        {
            int temp2 = S1.top();
            S1.pop();
            DQ1.push_front(temp2);
        }
    }
};
int main()
{
    SpecialStack SS1;
    SS1.push(11);
    SS1.push(12);
    SS1.push(13);
    SS1.push(14);
    SS1.push(15);
    SS1.middle();
    SS1.deleteMiddle();
    SS1.middle();
    SS1.deleteMiddle();
    SS1.middle();
    return 0;
}