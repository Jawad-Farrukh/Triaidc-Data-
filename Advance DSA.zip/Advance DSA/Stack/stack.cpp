#include<iostream>
using namespace std;
class Stack
{
    public:
        int* array;
        int size;
        int top;
        Stack()
        {
            size = 10;
            array = new int[size];
            top = -1;
        }
        Stack(int _size)
        {
            size = _size;
            array = new int[size];
            top = -1;
        }
        bool isFull()
        {
            if(top == size - 1)
                return 1;
            else
                return 0;
        }
        bool isEmpty()
        {
            if(top == -1)
                return 1;
            else
                return 0;
        }
        void push(int value)
        {
            if(isFull())
                cout<<"Stack Overflow"<<endl;
            else
            {
                top++;
                array[top] = value;
            }
        }
        int pop()
        {
            if(isEmpty())
                cout<<"Stack is already empty"<<endl;
            else
            {
                int tep = array[top];
                top--;
                return tep;
            }
        }
        void display()
        {

        }
};
int main()
{
    Stack S1;
    return 0;
}