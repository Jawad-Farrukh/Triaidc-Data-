#include<iostream>
#include<vector>
using namespace std;
class Graph
{
private:
    int numberOfVertices;
    vector<int>* adjacentVert;
public:
    Graph(int V)
    {
        numberOfVertices = V;
        adjacentVert = new vector<int> [V];
    }
    void addEdge(int scr , int dest)
    {
        adjacentVert[scr].push_back(dest);
        adjacentVert[dest].push_back(scr);
    }
    void path(vector<int> adj[] , int startingPoint , vector<bool> &visited , int endingPoint)
    {
        visited[startingPoint] = true;
        cout<<startingPoint<<" ";
        if(startingPoint == endingPoint)
            return;
        for(int u : adj[startingPoint])
        {
            if(visited[u] == false)
            {
                path(adj , u , visited , endingPoint);
            }
        }
    }
    void FindPath(int scr , int dest)
    {
        vector<bool> visited;
        visited.resize(numberOfVertices , false);
        path(adjacentVert , scr , visited , dest);
    }
};


int main()
{
    Graph g(4);
	g.addEdge(0, 1);
	g.addEdge(0, 2);
	g.addEdge(1, 2);
	g.addEdge(2, 0);
	g.addEdge(2, 3);
	g.addEdge(3, 3);
    g.FindPath(0 , 2);
}