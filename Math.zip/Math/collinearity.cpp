#include <iostream>
#include <math.h>
#include <vector>
#include <iomanip>
#include <sstream>
using namespace std;
class Point
{
public:
    float X;
    float Y;
    Point(float _X, float _Y)
    {
        X = _X;
        Y = _Y;
    }
};
bool isCollinear(vector<Point> Points)
{
    bool _isCollinear = false;
    int numberOfPoints = Points.size();
    vector<float>Distances;
    vector<float>Sums;
    for(int i = 0; i < Points.size(); i++)
    {
        for(int j = i + 1; j < Points.size(); j++)
        {
            float distance = sqrt(pow(Points[i].X - Points[j].X , 2) + pow(Points[i].Y - Points[j].Y , 2));
            distance = round(distance * 1000);
            Distances.push_back(distance);
        }
    }
    for(int i = 0; i < Distances.size(); i++)
    {
        for(int j = i + 1; j < Distances.size(); j++)
        {
            
        }
    }
}
int main()
{
    Point A(-2, -1);
    Point B(0, 3);
    Point C(1, 5);
    Point D(1, -1);
    vector<Point> PointSet = {A, B, C, D};
    // bool isCollinear = Collinearity(PointSet);
    // cout << "Is the set of points collinear? :" << isCollinear << endl;
    return 0;
}