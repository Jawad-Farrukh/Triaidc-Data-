#include <iostream>
#include <math.h>
using namespace std;
float logrithm(float x)
{
    float initial = (x - 1) / (x + 1);
    float series = 0;
    for (int i = 1; i <= 1000; i += 2)
    {
        series = series + (pow(initial, i) / i);
    }
    float answer = series * 2;
    return answer;
}
float logrithmWithBase(float x, float base)
{
    float numerator = logrithm(x);
    float denominator = logrithm(base);
    float answer = numerator / denominator;
    return answer;
}
int main()
{
    float x = 10;
    float answer = logrithm(x);
    cout << answer << endl;
    float bibimbup = logrithmWithBase(x, 14);
    cout << bibimbup << endl;
    return 0;
}