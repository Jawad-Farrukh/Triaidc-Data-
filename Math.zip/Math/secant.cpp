#include <iostream>
#include <math.h>
using namespace std;
float equation(float x)
{
    return x - 0.8 - (0.2 * sin(x));
}
float precisioin(float f, int places)
{
    float n = pow(10.0f, places);
    return round(f * n) / n;
}
float SecantFormula(float (*equation)(float x), float Pl, float Pm)
{
    float Pn = 0;
    float numerator = equation(Pm) * (Pm - Pl);
    float denominator = equation(Pm) - equation(Pl);
    Pn = Pm - (numerator / denominator);
    return Pn;
}
float SecantMethod(float (*equation)(float x), float upperIntervalValue, float lowerIntervalValue, int decimalPrecision)
{
    float division = (lowerIntervalValue - upperIntervalValue) / 3;
    float P0 = upperIntervalValue + division;
    float P1 = lowerIntervalValue - division;
    P0 = precisioin(P0, decimalPrecision);
    P1 = precisioin(P1, decimalPrecision);
    cout << "P0 = " << P0 << endl;
    cout << "P1 = " << P1 << endl;
    float Po = 0.1;
    float Pn = 0;
    float temp;
    int count = 0;
    float x = 0;
    while (1)
    {
        if (count == 0)
        {
            temp = SecantFormula(*equation, P0, P1);
            Pn = precisioin(temp, decimalPrecision);
            cout << "P" << count + 2 << "=" << Pn << endl;
        }
        else if (count == 1)
        {
            temp = SecantFormula(*equation, P1, Pn);
            Po = precisioin(temp, decimalPrecision);
            cout << "P" << count + 2 << "=" << Po << endl;
        }
        else if (count % 2 == 0)
        {
            temp = SecantFormula(*equation, Po, Pn);
            Pn = precisioin(temp, decimalPrecision);
            cout << "P" << count + 2 << "=" << Pn << endl;
        }
        else
        {
            temp = SecantFormula(*equation, Pn, Po);
            Po = precisioin(temp, decimalPrecision);
            cout << "P" << count + 2 << "=" << Po << endl;
        }
        if (Pn == Po)
            break;
        count++;
    }
    return Pn;
}
int main()
{
    float result = SecantMethod(&equation, 0, (M_PI) / 2, 4);
    cout << result << endl;
    return 0;
}