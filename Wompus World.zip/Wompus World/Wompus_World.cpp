#include<iostream>
#include<utility>
using namespace std;
int main()
{
    int World[4][4];
    // Since the world is a matrix then we use a pair of column and row for positioning
    pair<int , int> Wumpus;
    return 0;
}