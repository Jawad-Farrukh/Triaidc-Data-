// This file covers triadic operators for Triadic string (t_string) datatype.

#ifndef t_string_logical_operator_h
#define t_string_logical_operator_h

#include "Datatype/t_string.h"

/* Triadic logical operators (AND, OR, NOT).

1. Charles Peirce defined three Triadic conjunction (AND) and disjunction (OR) operators; and four Triadic NOT operators in his personal diary.
2. Peirce's ten (3 ANDs, 3 ORs, and 4 Nots) operators work as "Individual" defined here as toperatorName_1, t_operatorName_2, t_operatorName_3 respectively.
3. For Triadic conjunction and disjunction, an aggregation operator, namely "toperatorName" works as the "Singular".

*/

// First Triadic AND operator (Z) declared as tand_1. Its rule is F > L > T

t_string tand_1(t_string &v1, t_string &v2)
{
    t_string obj;
    switch (v1.get_Degree())
    {
    case T:
        //------------------------
        obj.set_Degree(v2.get_Degree());
        //----------------------
        break;
        // here we cannot check more because left side limit so answer will must limit
    case L:
        obj.set_Degree(v1.get_Degree());
        break;
    // here we cannot check more because left side false so answer will must false
    case F:
        obj.set_Degree(v1.get_Degree());
        break;
    }

    return obj;
}

// Second Triadic AND operator (Omega) declared as tand_2. Its rule is L > F > T.

t_string tand_2(t_string &v1, t_string &v2)
{
    t_string obj;
    switch (v1.get_Degree())
    {
    case T:
        //------------------------
        obj.set_Degree(v2.get_Degree());
        //----------------------
        break;
        // here we cannot check more because left side limit so answer will must limit
    case L:
        obj.set_Degree(v1.get_Degree());
        break;
    // here if left side false then if right l then answer change
    case F:
        if (v2.get_Degree() == L)
            obj.set_Degree(v2.get_Degree());
        else
            obj.set_Degree(v1.get_Degree());
        break;
    }
    return obj;
}

// Third Triadic AND operator (Psi) declared as tand_3. Its rule is F > T > L.

t_string tand_3(t_string &v1, t_string &v2)
{
    t_string obj;
    switch (v1.get_Degree())
    {
    case T:
        //------------------------
        if (v2.get_Degree() == L)
            obj.set_Degree(v1.get_Degree());
        else
            obj.set_Degree(v2.get_Degree());
        //----------------------
        break;
        // here we cannot check more because left side limit so answer will must limit
    case L:
        obj.set_Degree(v2.get_Degree());
        break;
    // here if left side false then if right l then answer change
    case F:
        obj.set_Degree(v1.get_Degree());
        break;
    }
    return obj;
}

// Singular Triadic AND operator (combining all three ANDs) declared as tand.

// It simply calls tand_1, tand_2, and tand_3 triadic operators defined above.

t_string tand(t_string &v1, t_string &v2)
{
    // AND3 WITH AND1 AND AND2
    t_string temp1;
    temp1 = tand_1(v1, v2);

    t_string temp2;
    temp2 = tand_2(v1, v2);

    t_string temp3;
    temp3 = tand_3(temp1, temp2);

    // AND3 WITH AND1 AND AND3
    t_string temp4;
    temp4 = tand_1(v1, v2);

    t_string temp5;
    temp5 = tand_3(v1, v2);

    t_string temp6;
    temp6 = tand_3(temp4, temp5);
    // AND3 WITH AND2 AND AND3
    t_string temp7;
    temp7 = tand_1(v1, v2);

    t_string temp8;
    temp8 = tand_2(v1, v2);

    t_string temp9;
    temp9 = tand_3(temp7, temp8);
    // AND3 WITH AND1 AND2 AND3
    t_string temp10;
    temp10 = tand_3(temp3, temp6);

    t_string temp11;
    temp11 = tand_3(temp9, temp10);
    return temp11;
}

// First Triadic OR operator (Omega) declared as tor_1. Its rule is T > L > F
//-----------------------------------or operator

t_string tor_1(t_string &v1, t_string &v2)
{
    t_string obj;
    switch (v1.get_Degree())
    {
    case T:
        //------------------------
        obj.set_Degree(v1.get_Degree());
        //----------------------
        break;
        // here we cannot check more because left side limit so answer will must limit
    case L:
        if (v2.get_Degree() == F)
            obj.set_Degree(v1.get_Degree());
        else
            obj.set_Degree(v2.get_Degree());
        break;
    // here if left side false then if right l then answer change
    case F:
        obj.set_Degree(v2.get_Degree());
        break;
    }
    return obj;
}

// Second Triadic OR operator (Y) declared as tor_2. Its rule is L > T > F

// or2

t_string tor_2(t_string &v1, t_string &v2)
{
    t_string obj;
    switch (v1.get_Degree())
    {
    case T:
        //------------------------
        if (v2.get_Degree() == F)
            obj.set_Degree(v1.get_Degree());
        else
            obj.set_Degree(v2.get_Degree());
        //----------------------
        break;
        // here we cannot check more because left side limit so answer will must limit
    case L:
        obj.set_Degree(v1.get_Degree());
        break;
    // here if left side false then if right l then answer change
    case F:
        obj.set_Degree(v2.get_Degree());
        break;
    }
    return obj;
}

// Third Triadic OR operator (Phi) declared as tor_3. Its rule is T > F > L

t_string tor_3(t_string &v1, t_string &v2)
{
    t_string obj;
    switch (v1.get_Degree())
    {
    case T:
        //------------------------
        obj.set_Degree(v1.get_Degree());
        //----------------------
        break;
        // here we cannot check more because left side limit so answer will must limit
    case L:
        obj.set_Degree(v2.get_Degree());
        break;
    // here if left side false then if right l then answer change
    case F:
        if (v2.get_Degree() == L)
            obj.set_Degree(v1.get_Degree());
        else
            obj.set_Degree(v2.get_Degree());
        break;
    }
    return obj;
}

// Singular Triadic OR operator (combining all three ORs) declared as tand.

// It simply calls tor_1, tor_2, and tor_3 triadic operators defined above.

t_string tor(t_string &v1, t_string &v2)
{
    // AND3 WITH AND1 AND AND2
    t_string temp1;
    temp1 = tor_1(v1, v2);

    t_string temp2;
    temp2 = tor_2(v1, v2);

    t_string temp3;
    temp3 = tor_3(temp1, temp2);

    // AND3 WITH AND1 AND AND3
    t_string temp4;
    temp4 = tor_1(v1, v2);

    t_string temp5;
    temp5 = tor_3(v1, v2);

    t_string temp6;
    temp6 = tor_3(temp4, temp5);
    // AND3 WITH AND2 AND AND3
    t_string temp7;
    temp7 = tor_1(v1, v2);

    t_string temp8;
    temp8 = tor_2(v1, v2);

    t_string temp9;
    temp9 = tor_3(temp7, temp8);
    // AND3 WITH AND1 AND2 AND3
    t_string temp10;
    temp10 = tor_3(temp3, temp6);

    t_string temp11;
    temp11 = tor_3(temp9, temp10);
    return temp11;
}

// First Triadic NOT operator (strong-negation) declared as tnot_1. Its rule is T -> F; F -> T; L -> F.

t_string tnot_1(t_string v)
{
    t_string obj;
    switch (v.get_Degree())
    {
    case T:
        obj.set_Degree(F);
        break;
    default:
        obj.set_Degree(T);
        break;
    }
    return obj;
}

// Second Triadic NOT operator (partial-negation) declared as tnot_2. Its rule is T -> L; F -> L; L -> L.

t_string tnot_2(t_string v)
{
    t_string obj;
    obj.set_Degree(L);
    return obj;
}

// Third Triadic NOT operator (Forward Cyclic-negation) declared as tnot_2. Its rule is T -> L; L -> F; F -> T.

t_string tnot_3(t_string v)
{
    t_string obj;
    switch (v.get_Degree())
    {
    case T:
        obj.set_Degree(L);
        break;
    case L:
        obj.set_Degree(F);
        break;
    case F:
        obj.set_Degree(T);
        break;
    }
    return obj;
}

// Fourth Triadic NOT operator (Backward Cyclic-negation) declared as tnot_4. Its rule is T -> F; L -> T; F -> L.

t_string tnot_4(t_string v)
{
    t_string obj;
    switch (v.get_Degree())
    {
    case T:
        obj.set_Degree(F);
        break;
    case L:
        obj.set_Degree(T);
        break;
    case F:
        obj.set_Degree(L);
        break;
    }
    return obj;
}

#endif