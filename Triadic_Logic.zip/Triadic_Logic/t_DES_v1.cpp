#include "Triadic.h"
// Array to hold 16 triadic keys
t_string round_keys[16];

// Function to circular shift the key chunk once
t_string shiftLeftOnce(t_string keyChunk)
{
    t_string shifted("", keyChunk.get_Degree());
    // Loop counter is 28 because we have to shift the half of key size after PC1 that is 56/2 = 28
    string temp = "";
    for (int i = 1; i < 28; i++)
    {
        temp += keyChunk.get_value()[i];
    }
    temp += keyChunk.get_value()[0];
    shifted.set_value(temp);
    return shifted;
}

// Function to circular shift the key chunk twice
t_string shiftLeftTwice(t_string keyChunk)
{
    t_string shifted("", keyChunk.get_Degree());
    // Loop counter is 28 because we have to shift the half of key size after PC1 that is 56/2 = 28
    string temp = "";
    for (int i = 0; i < 2; i++)
    {
        for (int j = 1; j < 28; j++)
        {
            temp += keyChunk.get_value()[j];
        }
        temp += keyChunk.get_value()[0];
        keyChunk.set_value(temp);
        temp = "";
    }
    shifted.set_value(keyChunk.get_value());
    return shifted;
}

// Function to create keys
void key_generation(t_string key)
{
    // Permutation Choice 1 table
    int PermutationChoice1[56] = {57, 49, 41, 33, 25, 17, 9,
                                  1, 58, 50, 42, 34, 26, 18,
                                  10, 2, 59, 51, 43, 35, 27,
                                  19, 11, 3, 60, 52, 44, 36,
                                  63, 55, 47, 39, 31, 23, 15,
                                  7, 62, 54, 46, 38, 30, 22,
                                  14, 6, 61, 53, 45, 37, 29,
                                  21, 13, 5, 28, 20, 12, 4};

    // Permutation Choice 2 table
    int PermutationChoice2[48] = {14, 17, 11, 24, 1, 5,
                                  3, 28, 15, 6, 21, 10,
                                  23, 19, 12, 4, 26, 8,
                                  16, 7, 27, 20, 13, 2,
                                  41, 52, 31, 37, 47, 55,
                                  30, 40, 51, 45, 33, 48,
                                  44, 49, 39, 56, 34, 53,
                                  46, 42, 50, 36, 29, 32};

    // Initial Size of key is 64 so we have to do permuatation choice 1 to make it 56
    t_string PermutationChoice1Key("", key.get_Degree());
    string temp = "";
    for (int i = 0; i < 56; i++)
    {
        temp += key.get_value()[PermutationChoice1[i] - 1];
    }
    PermutationChoice1Key.set_value(temp);

    // Dividing into halves
    t_string keyLeft = PermutationChoice1Key.substr(0, 28);
    t_string keyRight = PermutationChoice1Key.substr(28, 28);

    // Generating 16 keys
    for (int i = 0; i < 16; i++)
    {
        // For Round No. 1 , 2 , 9 and 16 the keys chunks are shifted once
        if (i == 0 || i == 1 || i == 8 || i == 15)
        {
            keyLeft = shiftLeftOnce(keyLeft);
            keyRight = shiftLeftOnce(keyRight);
        }
        // For other rounds the key chunks will be shifted twice
        else
        {
            keyLeft = shiftLeftTwice(keyLeft);
            keyRight = shiftLeftTwice(keyRight);
        }

        // Combining key chunks
        t_string combinedKey(keyLeft.get_value() + keyRight.get_value(), key.get_Degree());
        t_string roundKey("", key.get_Degree());
        temp = "";

        // Now we have to permutation choice 2 to make the key 48
        for (int j = 0; j < 48; j++)
        {
            temp += key.get_value()[PermutationChoice2[j] - 1];
        }
        roundKey.set_value(temp);
        round_keys[i] = roundKey;
        cout << "Key for round " << i + 1 << " : " << round_keys[i].get_value() << endl;
    }
}

// Triadic Xor
t_string Xor(t_string key, t_string plainText)
{
    t_string result("", plainText.get_Degree());
    string temp = "";
    int _size = plainText.size();
    t_string ans = tand(plainText, key);
    for (int i = 0; i < _size; i++)
    {
        if (ans.get_Degree() == T)
        {
            if (key.get_value()[i] == plainText.get_value()[i])
                temp += "0";
            else
                temp += "1";
        }
        else if (ans.get_Degree() == F)
        {
            if (key.get_value()[i] == plainText.get_value()[i])
                temp += "1";
            else
                temp += "0";
        }
    }
    result.set_value(temp);
    return result;
}

// Binary to Decimal
int BinaryToDecimalConversion(string binary)
{
    int decimal = 0;
    int counter = 0;
    int size = binary.length();
    for (int i = size - 1; i >= 0; i--)
    {
        if (binary[i] == '1')
        {
            decimal += pow(2, counter);
        }
        counter++;
    }
    return decimal;
}

// Decimal to Binary
string DecimalToBinaryConversion(int decimal)
{
    string binary;
    while (decimal != 0)
    {
        binary = (decimal % 2 == 0 ? "0" : "1") + binary;
        decimal = decimal / 2;
    }
    while (binary.length() < 4)
    {
        binary = "0" + binary;
    }
    return binary;
}

// The Triadic DES Algorithm
t_string DES(t_string plainText)
{
    // Initial Permutation
    int initial_permutation[64] = {58, 50, 42, 34, 26, 18, 10, 2,
                                   60, 52, 44, 36, 28, 20, 12, 4,
                                   62, 54, 46, 38, 30, 22, 14, 6,
                                   64, 56, 48, 40, 32, 24, 16, 8,
                                   57, 49, 41, 33, 25, 17, 9, 1,
                                   59, 51, 43, 35, 27, 19, 11, 3,
                                   61, 53, 45, 37, 29, 21, 13, 5,
                                   63, 55, 47, 39, 31, 23, 15, 7};

    // Expansion Table
    int expansion_table[48] = {32, 1, 2, 3, 4, 5, 4, 5,
                               6, 7, 8, 9, 8, 9, 10, 11,
                               12, 13, 12, 13, 14, 15, 16, 17,
                               16, 17, 18, 19, 20, 21, 20, 21,
                               22, 23, 24, 25, 24, 25, 26, 27,
                               28, 29, 28, 29, 30, 31, 32, 1};

    // Substitution Table. There are Eight S-Boxes. Each Box ha 4 Rows. Each Row has 16 Entries.
    int substition_boxes[8][4][16] =
        {{14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7,
          0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8,
          4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0,
          15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13},
         {15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10,
          3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5,
          0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15,
          13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9},
         {10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8,
          13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1,
          13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7,
          1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12},
         {7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15,
          13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9,
          10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4,
          3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14},
         {2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9,
          14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
          4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14,
          11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3},
         {12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11,
          10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
          9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6,
          4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13},
         {4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1,
          13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
          1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2,
          6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12},
         {13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7,
          1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
          7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8,
          2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11}};

    // Permutation Table
    int permutation_table[32] = {16, 7, 20, 21, 29, 12, 28, 17,
                                 1, 15, 23, 26, 5, 18, 31, 10,
                                 2, 8, 24, 14, 32, 27, 3, 9,
                                 19, 13, 30, 6, 22, 11, 4, 25};

    // The Inverse Permutation Table
    int inverse_permutation[64] = {40, 8, 48, 16, 56, 24, 64, 32,
                                   39, 7, 47, 15, 55, 23, 63, 31,
                                   38, 6, 46, 14, 54, 22, 62, 30,
                                   37, 5, 45, 13, 53, 21, 61, 29,
                                   36, 4, 44, 12, 52, 20, 60, 28,
                                   35, 3, 43, 11, 51, 19, 59, 27,
                                   34, 2, 42, 10, 50, 18, 58, 26,
                                   33, 1, 41, 9, 49, 17, 57, 25};

    // Performing Inital Permutation
    t_string permutationString("", plainText.get_Degree());
    string temp = "";
    for (int i = 0; i < 64; i++)
        temp += plainText.get_value()[inverse_permutation[i]];
    permutationString.set_value(temp);

    // Dividing into halves
    t_string left = permutationString.substr(0, 32);
    t_string right = permutationString.substr(32, 32);

    // The plain text is encrpted 16 times
    for (int i = 0; i < 16; i++)
    {
        t_string rightExpansion("", plainText.get_Degree());
        temp = "";
        for (int j = 0; j < 48; j++)
            temp += right.get_value()[expansion_table[j] - 1];
        rightExpansion.set_value(temp);

        t_string Xored = Xor(round_keys[i], rightExpansion);
        t_string res("", Xored.get_Degree());
        temp = "";

        // The result is divided into 8 equal parts and passed
        //  through 8 substitution boxes. After passing through a
        //  substituion box, each box is reduces from 6 to 4 bits.

        for (int i = 0; i < 8; i++)
        {
            string row1 = Xored.substr(i * 6, 1).get_value() + Xored.substr(i * 6 + 5, 1).get_value();
            int row = BinaryToDecimalConversion(row1);
            string col1 = Xored.substr(i * 6 + 1, 1).get_value() + Xored.substr(i * 6 + 2, 1).get_value() + Xored.substr(i * 6 + 3, 1).get_value() + Xored.substr(i * 6 + 4, 1).get_value();
            int col = BinaryToDecimalConversion(col1);
            int val = substition_boxes[i][row][col];
            temp += DecimalToBinaryConversion(val);
        }
        res.set_value(temp);
        t_string perm2("" , res.get_Degree());
        temp = "";
        for(int i = 0; i < 32; i++)
        {
            temp += res.get_value()[permutation_table[i] - 1];
        }
        perm2.set_value(temp);
        Xored = Xor(perm2 , left);
        left = Xored;

        //Swaping Left and Right
        if(i < 15)
        {
            t_string temporary = right;
            right = Xored;
            left = temporary;
        }

    }
    t_string combinedText(left.get_value() + right.get_value() , plainText.get_Degree());
    t_string cipherText("" , combinedText.get_Degree());
    temp = "";
    for(int i = 0; i < 64; i++)
    {
        temp += combinedText.get_value()[inverse_permutation[i] - 1];
    }
    cipherText.set_value(temp);
    return cipherText;
}
int main()
{
    t_string keyChunk("JawadFarrukhIsAStudentOfUCP.", T);
    cout << "Original String: ";
    t_print(keyChunk);
    cout << endl;
    cout << "Shifted String: ";
    keyChunk = shiftLeftTwice(keyChunk);
    t_print(keyChunk);
    t_string left = keyChunk.substr(0, 14);
    t_string right = keyChunk.substr(14, 14);
    t_print(left);
    t_print(right);
    cout << endl;
    return 0;
}