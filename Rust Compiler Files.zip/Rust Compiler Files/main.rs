mod compiler;
mod create;
mod list_q;
mod remove;
mod rename;
mod use_q;
use std::io;
pub fn promt() -> String {
    println!("db>");

    let mut query = String::new();
    io::stdin()
        .read_line(&mut query)
        .expect("Failed to read line");
    return query;
}
fn main() {
    while (true) {
        let query = promt();
        let trimmed_input = query.trim();
        if trimmed_input.eq_ignore_ascii_case("Exit"){
            break;
        }
        if create::create::is_create_database_query(&query).is_ok {
            println!("This is a Create Database Query");
        } else if remove::remove::is_remove_database_query(&query).is_ok {
            println!("This is a Remove Database Query");
        } else if rename::rename::is_rename_database_query(&query).is_ok {
            println!("This is a Remove Database Query");
        } else if use_q::use_q::is_use_database_query(&query).is_ok {
            println!("This is a Use Database Query");
        } else if list_q::list_q::is_list_database_query(&query).is_ok {
            println!("This is a List Database Query");
        } else {
            println!("This is Not Valid Query");
        }
    }
}
