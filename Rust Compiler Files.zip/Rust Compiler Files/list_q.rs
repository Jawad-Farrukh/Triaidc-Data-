pub struct Database {
    pub database_name: String,
    pub is_ok: bool,
}

impl Database {
    pub fn new(database_name: String, is_ok: bool) -> Self {
        Self { database_name, is_ok, }
    }
}

pub mod list_q {
    use super::Database;
    pub fn is_list_database_query(query: &String) -> Database {
        let tokens: Vec<&str> = query.split_whitespace().collect();
        let number_of_tokens = tokens.len();
        if number_of_tokens < 3 {
            return Database::new("Null".to_string(), false);
        } else if number_of_tokens > 3 {
            return Database::new("Null".to_string(), false);
        } else {
            if tokens[0] == "list" {
                if tokens[1] == "database" {
                    return Database::new(tokens[2].to_string(), true);
                } else {
                    return Database::new("Null".to_string(), false);
                }
            } else {
                return Database::new("Null".to_string(), false);
            }
        }
    }
}
