
pub fn is_list_database_query(query:&mut String) -> bool {
    let tokens: Vec<&str> = query.split_whitespace().collect();
    let number_of_tokens = tokens.len();
    if number_of_tokens < 3 {
        return false;
    } else if number_of_tokens > 3 {
        return false;
    } else {
        if tokens[0] == "list" {
            if tokens[1] == "database" {
                println!("listing Database in {}", tokens[2]);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}