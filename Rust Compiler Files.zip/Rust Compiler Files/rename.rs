pub struct Database {
    pub database_name: String,
    pub is_ok: bool,
    pub database_new_name: String,
}

impl Database {
    pub fn new(database_name: String, is_ok: bool, database_new_name: String) -> Self {
        Self {
            database_name,
            is_ok,
            database_new_name,
        }
    }
}

pub struct TableInfo {
    pub table_name: String,
    pub is_ok: bool,
    pub attribute_names: Vec<String>,
    pub datatypes: Vec<String>,
}

pub mod rename {
    use super::Database;
    pub fn is_rename_database_query(query: &String) -> Database {
        let tokens: Vec<&str> = query.split_whitespace().collect();
        let number_of_tokens = tokens.len();
        if number_of_tokens < 4 {
            return Database::new("Null".to_string(), false, "Null".to_string());
        } else if number_of_tokens > 4 {
            return Database::new("Null".to_string(), false, "Null".to_string());
        } else {
            if tokens[0] == "rename" {
                if tokens[1] == "database" {
                    return Database::new(tokens[2].to_string(), true, tokens[3].to_string());
                } else {
                    return Database::new("Null".to_string(), false, "Null".to_string());
                }
            } else {
                return Database::new("Null".to_string(), false, "Null".to_string());
            }
        }
    }
}
